This repository contains scripts used to build ASP.NET Core and Entity Framework Core.

These scripts are not supported products of Microsoft and are intended for Microsoft use only.
